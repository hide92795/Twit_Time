import javax.swing.SwingUtilities;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.UIManager;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.Toolkit;
import javax.swing.JScrollPane;
import java.awt.Rectangle;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.SwingWorker;

import java.awt.Color;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import twitter4j.Paging;
import twitter4j.ResponseList;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.http.AccessToken;

public class mainwindow extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JScrollPane jScrollPane = null;
	private static JTextArea jTextArea = null;
	private static JTextField jTextField = null;
	private JButton jButton = null;
	private JButton jButton1 = null;
	private static JButton jButton2 = null;
	private JButton jButton3 = null;
	private JLabel jLabel = null;
	private JComboBox jComboBox = null;
	private JButton jButton4 = null;
	private static JButton jButton5 = null;
	private JScrollPane jScrollPane1 = null;
	private JTable jTable = null;
	protected boolean show_detail = false;
	protected static boolean show_date_format = true;
	protected static boolean add_a = true;
	static DefaultComboBoxModel comboboxmodel;
	protected static mainwindow frame;
	static String[] columnNames = {"No.", "����", "����"};
	public static DefaultTableModel tableModel = new DefaultTableModel(columnNames , 0);
	private static String user;
	private static Twitter twitter;
	private static TwitterFactory twitterfactory;
	private static String DATE_PATTERN1 = "HH':'mm':'ss";
	private static String DATE_PATTERN2 = "HH'��'mm'��'ss'�b'";
	static SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_PATTERN1);//11:22:33
	static SimpleDateFormat sdf2 = new SimpleDateFormat(DATE_PATTERN2);//11��22��33�b
	private static String kaijo_date;
	
	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(0, 0, 540, 330));
			jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			jScrollPane.setViewportView(getJTextArea());
		}
		return jScrollPane;
	}

	/**
	 * This method initializes jTextArea	
	 * 	
	 * @return javax.swing.JTextArea	
	 */
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
			jTextArea.setLineWrap(true);
			jTextArea.setEditable(false);
			jTextArea.setCursor(new Cursor(Cursor.TEXT_CURSOR));
		}
		return jTextArea;
	}

	/**
	 * This method initializes jTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField() {
		if (jTextField == null) {
			jTextField = new JTextField();
			jTextField.setBounds(new Rectangle(10, 370, 530, 18));
			jTextField.setBackground(Color.white);
			jTextField.setEditable(false);
		}
		return jTextField;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(470, 340, 70, 25));
			jButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton.setText("�N���A");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					jTextField.setText("");
					jButton.setEnabled(false);
					jButton1.setEnabled(true);
					jButton2.setEnabled(false);
					jButton3.setEnabled(false);
					jButton4.setEnabled(true);
					jButton5.setEnabled(false);
					jButton5.setText("�ڍ׉�ʁ�");
					show_detail = false;
					frame.setSize(550, 460);
					jComboBox.setEnabled(true);
					tableModel.setRowCount(0);
					status_print("�N���A���܂���");
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(390, 340, 70, 25));
			jButton1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton1.setText("�ݒ�");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					settingwindow thisClass1 = new settingwindow(null);
					thisClass1.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
					thisClass1.setVisible(true);
				}
			});
		}
		return jButton1;
	}

	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setBounds(new Rectangle(10, 340, 170, 25));
			jButton2.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton2.setEnabled(false);
			jButton2.setText("���������莞�����R�s�[");
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
					StringSelection selection = new StringSelection(kaijo_date);
					clipboard.setContents(selection, selection);
					status_print("�N���b�v�{�[�h�ɃR�s�[���܂���");
				}
			});
		}
		return jButton2;
	}

	/**
	 * This method initializes jButton3	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton3() {
		if (jButton3 == null) {
			jButton3 = new JButton();
			jButton3.setBounds(new Rectangle(190, 340, 120, 25));
			jButton3.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton3.setEnabled(false);
			jButton3.setText("���S�����R�s�[");
			jButton3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
					StringSelection selection = new StringSelection(jTextField.getText());
					clipboard.setContents(selection, selection);
					status_print("�N���b�v�{�[�h�ɃR�s�[���܂���");
				}
			});
		}
		return jButton3;
	}

	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox() {
		if (jComboBox == null) {
			jComboBox = new JComboBox(comboboxmodel);
			jComboBox.setBounds(new Rectangle(180, 400, 142, 21));
			jComboBox.setEditable(true);
		}
		return jComboBox;
	}

	/**
	 * This method initializes jButton4	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton4() {
		if (jButton4 == null) {
			jButton4 = new JButton();
			jButton4.setBounds(new Rectangle(330, 398, 70, 25));
			jButton4.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton4.setText("�擾");
			jButton4.addActionListener(new java.awt.event.ActionListener() {
				@Override public void actionPerformed(java.awt.event.ActionEvent e) {
					if(comboboxmodel.getSelectedItem().equals("")){
					}else{
						jButton.setEnabled(false);
						jButton1.setEnabled(false);
						jButton4.setEnabled(false);
						jComboBox.setEnabled(false);
						new SwingWorker<Object, Object>() {
							@Override public Object doInBackground() {
								get_data();
								return "Done";
							}
							@Override public void done() {
								jButton.setEnabled(true);
								jButton3.setEnabled(true);
								jButton5.setEnabled(true);
								
							}
						}.execute();
					}
				}
			});
		}
		return jButton4;
	}
	
	private static void get_data() {
		status_print("�f�[�^�̎擾���J�n���܂�");
		String user_token[] = new String[2];
		user = (String)comboboxmodel.getSelectedItem();
		status_print("���[�U�[�F" + user);
		int index = 0;
		File file = new File("./user/" + user + ".txt");
		if(file.exists()){
			try{
				FileReader in = new FileReader(file);
				BufferedReader br = new BufferedReader(in);
				String line;
				while ((line = br.readLine()) != null) {
					user_token[index] = line;
					index++;
				}
				br.close();
				in.close();
			}catch(IOException e1){
				System.out.println(e1 + "��O���������܂���");
			}
		}else{
			user_token[0] = "";
			user_token[1] = "";
		}
		
		//TODO---------------------------------------------�擾�J�n(Twitter�F��)---------------------------------------
		twitter = null;
		
		ConfigurationBuilder confbuilder = new ConfigurationBuilder();
		confbuilder.setIncludeEntitiesEnabled(false);
		
		String CONSUMERKEY ="cSq91PiOmq2BTI5WdoKGdQ";
		String CONSUMERSECRET ="TfggWiV8jhmSAhuOFtGP2cOn3PhuALz9ultwViNGo";
		String ACCESSTOKEN = user_token[0];
		String ACCESSSECRET = user_token[1];
		
		confbuilder.setOAuthConsumerKey(CONSUMERKEY);
		confbuilder.setOAuthConsumerSecret(CONSUMERSECRET);
		
		twitterfactory = new TwitterFactory(confbuilder.build());
		if(user_token[0].equals("")){
			status_print("���[�U�[�t�@�C����������Ȃ����߁A���O�C�������Ɏ擾���܂�");
			twitter = twitterfactory.getInstance();
		}else{
			twitter = twitterfactory.getOAuthAuthorizedInstance(new AccessToken(ACCESSTOKEN,ACCESSSECRET));
			status_print("���[�U�[�t�@�C���������������߁A���O�C�����Ď擾���܂�");
		}
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN1);
		
		Paging paging = new Paging(1,200);
		String status_data[] = new String[3];
		int count = 0;
		
		try{
			ResponseList<Status> statuses = twitter.getUserTimeline(user,paging);
			if(statuses != null){
				for(Status status :statuses){
					count++;
					status_data[0] = String.valueOf(count);
					status_data[1] = sdf.format(status.getCreatedAt());
					status_data[2] = String.valueOf(status.getCreatedAt().getTime());
					tableModel.addRow(status_data);
				}
			}
		}catch(TwitterException e){
			status_print("�G���[���������܂���" + e);
			e.printStackTrace();
		}
		status_print("�f�[�^�̎擾���������܂���");
		//TODO---------------------------------------------Twitter�F�؏I��---------------------------------------
		status_print("�K���������莞�����Z�o���܂�");
				
		long date1_temp = Long.parseLong(tableModel.getValueAt(0,2).toString());
		long date2_temp = Long.parseLong(tableModel.getValueAt(126,2).toString());
		long date_temp = date1_temp - date2_temp;
		Date date1 = new Date(date1_temp);
		Date date2 = new Date(date2_temp);
		status_print("�ŐV�̃c�C�[�g�F" + date1);
		status_print("127�c�C�[�g�O�F" + date2);
		status_print("2�̃c�C�[�g�̎��ԍ��F" + date_temp + "ms");
		if(date_temp > 10800000){
			//�K������Ă��Ȃ�
			int ret = JOptionPane.showConfirmDialog (null, user + "�͂܂��K������Ă��Ȃ��悤�ł��B\n�K���܂ł̃c�C�[�g��������o���܂����H", "Twit Sync", JOptionPane.YES_NO_OPTION);
			if(ret == JOptionPane.YES_OPTION) {
				//�K���܂ŉ��c�C�[�g
				int check_count = 0;
				Date date3 = new Date();
				long date4 = date3.getTime();
				long date4_temp = 0;
				check_finish:
				for(int i = 125; i >= 0; i--){
					check_count++;
					date4_temp = Long.parseLong(tableModel.getValueAt(i,2).toString());
					long date5_temp = date4 - date4_temp;
					if(date5_temp < 10800000){
						break check_finish;
					}
				}
				String kisei_date = null;
				long date5 = date4_temp + 10800000;
				long date6 = date5 - date4;
				if(date6 < 0){
					date6 = 10800000;
				}
				date6 = date6 / 1000;//�b
				System.out.println(date6);
				long date6_byou = date6 % 60;
				date6 = date6 / 60;//��
				System.out.println(date6);
				long date6_hun = date6 % 60;
				date6 = date6 / 60;//��
				System.out.println(date6);
				if(date6 == 0){
					kisei_date = date6_hun + "��" + date6_byou + "�b";
				}else{
					kisei_date = date6 + "����" + date6_hun + "��" + date6_byou + "�b";
				}
				if(add_a == true){
					jTextField.setText("@" + user + " ��" + kisei_date + "��" + check_count + "�c�C�[�g����ƋK�������悤�ł��B");
				}else{
					jTextField.setText(user + " ��" + kisei_date + "��" + check_count + "�c�C�[�g����ƋK�������悤�ł��B");
				}
			}else{
				long date5 = date2_temp + 10800000;
				Date date6 = new Date(date5);
				if(show_date_format == false){
					kaijo_date = sdf1.format(date6);
				}else{
					kaijo_date = sdf2.format(date6);
				}
				setting_text();
				jButton2.setEnabled(true);
			}
		}else{
			//�K������Ă���
			Date date3 = new Date();
			long date4 = date3.getTime();
			long date5 = date2_temp + 10800000;
			status_print("���݂̎����F" + date3);
			//��-(127�c�C�[�g+3hour)
			Date date6 = new Date(date5);
			if(show_date_format == false){
				kaijo_date = sdf1.format(date6);
			}else{
				kaijo_date = sdf2.format(date6);
			}
			long date3_temp = date4 - date5;
			if(date3_temp > 0){
				//�K������Ă������A���ɉ�������Ă���
				JOptionPane.showMessageDialog(null, user + "�͋K������Ă��܂������A" + kaijo_date + "���ɋK���������ꂽ�悤�ł��B", "Twit Sync", JOptionPane.INFORMATION_MESSAGE);
				setting_text();
			}else{
				//��������Ă��Ȃ�
				setting_text();
			}
			jButton2.setEnabled(true);
		}
		status_print("�I�����܂���");
	}

	private static void setting_text() {
		if(add_a == true){
			jTextField.setText("@" + user + " �̉������莞���� " + kaijo_date + " �ł��B");
		}else{
			jTextField.setText(user + " �̉������莞���� " + kaijo_date + " �ł��B");
		}
	}

	private static void status_print(String mes) {
		System.out.println(mes);
		jTextArea.append(mes + "\n");
		jTextArea.setCaretPosition(jTextArea.getText().length());
	}

	/**
	 * This method initializes jButton5	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton5() {
		if (jButton5 == null) {
			jButton5 = new JButton();
			jButton5.setBounds(new Rectangle(440, 398, 100, 25));
			jButton5.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton5.setEnabled(false);
			jButton5.setText("�ڍ׉�ʁ�");
			jButton5.addActionListener(new java.awt.event.ActionListener() {
				@Override public void actionPerformed(java.awt.event.ActionEvent e) {
					if(show_detail == false){
						frame.setSize(667, 460);
						jButton5.setText("��ڍ׉��");
						show_detail = true;
					}else{
						frame.setSize(550, 460);
						jButton5.setText("�ڍ׉�ʁ�");
						show_detail = false;
					}
				}
			});
		}
		return jButton5;
	}

	/**
	 * This method initializes jScrollPane1	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setBounds(new Rectangle(545, 0, 114, 430));
			jScrollPane1.setBackground(Color.white);
			jScrollPane1.setViewportView(getJTable());
		}
		return jScrollPane1;
	}

	/**
	 * This method initializes jTable	
	 * 	
	 * @return javax.swing.JTable	
	 */
	private JTable getJTable() {
		if (jTable == null) {
			jTable = new JTable(tableModel);
			jTable.setDefaultEditor(Object.class, null);					//�Z����ҏW�s��
			jTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);	//�����ɂQ�̗�̑I����s��
			jTable.setShowGrid(false);										//�c���̐���\�������Ȃ�
			jTable.getTableHeader().setReorderingAllowed(false);			//�J�����ړ��s��
			jTable.setCellSelectionEnabled(true);
			jTable.setBackground(Color.white);
			jTable.setColumnSelectionAllowed(false);
			jTable.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					if(e.getClickCount()==2) {
						Point pt = e.getPoint();
						int row = jTable.convertRowIndexToModel(jTable.rowAtPoint(pt));
						long rev_date = Long.parseLong(tableModel.getValueAt(row, 2).toString());
						rev_date = rev_date + 10800000;
						if(show_date_format == false){
							kaijo_date = sdf1.format(rev_date);
						}else{
							kaijo_date = sdf2.format(rev_date);
						}
						setting_text();
					}
				}
			});
			
			String osName = System.getProperty("os.name");
			
			int column_Windows = 50;
			int column_Mac = 45;
			int column_Linux = 39;
			int column_size;
			
			if(osName.startsWith("Mac OS")){
				column_size = column_Mac;
			}else if(osName.startsWith("Windows")){
				column_size = column_Windows;
			}else{
				column_size = column_Linux;
			}
			
			TableColumn col = jTable.getColumnModel().getColumn(0);
			col.setPreferredWidth(column_size);
			
			TableColumn col1 = jTable.getColumnModel().getColumn(2);
			col1.setMinWidth(0);
			col1.setMaxWidth(0);
			
		}
		return jTable;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				//�V�X�e���ŗL��GUI�Ăяo��
				try{
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				}catch(Exception e) {
					e.printStackTrace();
				}
				comboboxmodel = new DefaultComboBoxModel();
				System.out.println("�ݒ��ǂݍ��݂܂�");
				File file = new File("./setting.txt");
				if(file.exists()){
					try{
						System.out.println("�ݒ�t�@�C�����m�F���܂���");
						FileReader in = new FileReader(file);
						BufferedReader br = new BufferedReader(in);
						String line;
						int count = 0;
						int user_count = 0;
						int set_count = 0;
						while ((line = br.readLine()) != null) {
							if(count == 0){
								user_count = Integer.parseInt(line);
							}else if(count <= user_count){
								comboboxmodel.addElement(line);
							}else{
								if(set_count == 0){
									if(Integer.parseInt(line) == 0){
										add_a = false;
									}
								}else{
									if(Integer.parseInt(line) == 0){
										show_date_format = false;
									}
								}
								set_count++;
							}
							count++;
						}
						br.close();
						in.close();
					}catch(IOException e){
						System.out.println(e + "��O���������܂���");
					}
				}else{
					System.out.println("�ݒ�t�@�C��������܂���B");
					System.out.println("�V�����ݒ�t�@�C�����쐬���܂��B");
					try{
						file.createNewFile();
						if (checkBeforeWritefile(file)){
							PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));    
							pw.println("0");
							pw.println("1");
							pw.println("1");
							pw.close();
						}else{
							System.out.println("�t�@�C���ɏ������߂܂���");
						}
					}catch(IOException f){
						System.out.println(f + "��O���������܂���");
					}
				}
				frame = new mainwindow();
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
				jTextArea.append("�N�����܂���\n");
			}
		});
	}

	protected static boolean checkBeforeWritefile(File file) {
		//�t�@�C���������ݎ��̏������݉\���`�F�b�N����
		if (file.exists()){
			if (file.isFile() && file.canWrite()){
				return true;
			}
			}
		return false;
	}

	/**
	 * This is the default constructor
	 */
	public mainwindow() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/icon.png")));
		this.setBounds(new Rectangle(0, 0, 550, 460));
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setContentPane(getJContentPane());
		this.setTitle("Twit Time -Twitter�K���������Ԋ���o���v���O����-");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(100, 401, 76, 16));
			jLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
			jLabel.setHorizontalAlignment(SwingConstants.RIGHT);
			jLabel.setText("���[�U�[���F");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(getJTextField(), null);
			jContentPane.add(getJButton(), null);
			jContentPane.add(getJButton1(), null);
			jContentPane.add(getJButton2(), null);
			jContentPane.add(getJButton3(), null);
			jContentPane.add(jLabel, null);
			jContentPane.add(getJComboBox(), null);
			jContentPane.add(getJButton4(), null);
			jContentPane.add(getJButton5(), null);
			jContentPane.add(getJScrollPane1(), null);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
