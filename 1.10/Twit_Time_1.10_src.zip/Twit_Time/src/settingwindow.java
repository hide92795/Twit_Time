import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JPanel;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JList;
import java.awt.Rectangle;
import javax.swing.JButton;
import java.awt.Font;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.http.AccessToken;
import twitter4j.http.RequestToken;
import javax.swing.JScrollPane;

public class settingwindow extends JDialog {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JList jList = null;
	private JButton jButton = null;
	private DefaultListModel model;
	private JTextField jTextField = null;
	private JButton jButton1 = null;
	static ButtonGroup group = new ButtonGroup();
	static ButtonGroup group1 = new ButtonGroup();  //  @jve:decl-index=0:
	private JRadioButton jRadioButton = null;
	private JRadioButton jRadioButton1 = null;
	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JRadioButton jRadioButton2 = null;
	private JRadioButton jRadioButton3 = null;
	private JButton jButton2 = null;
	private JScrollPane jScrollPane = null;
	/**
	 * @param owner
	 */
	public settingwindow(Frame owner) {
		super(owner);
		initialize();
		load_setting();
	}

	private void load_setting() {
		System.out.println("�ݒ�Ǎ�");
		for(int i = 0; i<mainwindow.comboboxmodel.getSize(); i++){
			model.addElement(mainwindow.comboboxmodel.getElementAt(i));
		}
		if(mainwindow.add_a == true){
			jRadioButton.setSelected(true);
		}else{
			jRadioButton1.setSelected(true);
		}
		if(mainwindow.show_date_format == true){
			jRadioButton2.setSelected(true);
		}else{
			jRadioButton3.setSelected(true);
		}
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setModal(true);
		this.setBounds(new Rectangle(0, 0, 300, 335));
		this.setResizable(false);
		this.setTitle("�ݒ�");
		this.setLocationRelativeTo(null);
		this.setContentPane(getJContentPane());
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.out.println("x�{�^����������");
				save_setting();
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(10, 220, 84, 18));
			jLabel1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jLabel1.setText("���ԕ\���`��");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(10, 170, 71, 18));
			jLabel.setFont(new Font("Dialog", Font.PLAIN, 12));
			jLabel.setText("�u@�v�ǉ�");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJScrollPane(), null);
			jContentPane.add(getJButton(), null);
			jContentPane.add(getJTextField(), null);
			jContentPane.add(getJButton1(), null);
			jContentPane.add(getJRadioButton(), null);
			jContentPane.add(getJRadioButton1(), null);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLabel1, null);
			jContentPane.add(getJRadioButton2(), null);
			jContentPane.add(getJRadioButton3(), null);
			jContentPane.add(getJButton2(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jList	
	 * 	
	 * @return javax.swing.JList	
	 */
	private JList getJList() {
		if (jList == null) {
			model = new DefaultListModel();
			jList = new JList(model);
		}
		return jList;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new Rectangle(120, 130, 70, 25));
			jButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton.setText("�ǉ�");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("�ǉ��{�^�����N���b�N");
					if (jTextField.getText().length() == 0){								//�e�L�X�g�ɓ��͂��ꂽ�������󂩔��f
						System.out.println("�e�L�X�g����ł�");
					}else{
						boolean isFound = false;
						String add_user = (String)jTextField.getText();
						for (int i = 0; i < model.getSize(); i++) {							//���X�g���̍��ڐ���J��Ԃ�
							if(add_user.equals(model.getElementAt(i))) {					//���X�g���̃��[�U�[�Ɋ��ɂ��邩���f
								isFound = true;
								System.out.println("���͂��ꂽ���[�U�[�͊��ɑ��݂��Ă��܂� - " + add_user);
								break;
							}
				        }
						if(!isFound) {
							System.out.println("���[�U�[��ǉ����܂��� - " + add_user);
							model.addElement(new String(jTextField.getText()));				//���X�g�ɒǉ�
							jTextField.setText("");
						}
					}
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextField() {
		if (jTextField == null) {
			jTextField = new JTextField();
			jTextField.setBounds(new Rectangle(10, 130, 100, 20));
		}
		return jTextField;
	}

	/**
	 * This method initializes jButton1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton1() {
		if (jButton1 == null) {
			jButton1 = new JButton();
			jButton1.setBounds(new Rectangle(200, 130, 70, 25));
			jButton1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton1.setText("�폜");
			jButton1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("�폜�{�^�����N���b�N");
					int index = jList.getSelectedIndex();
					if (index == -1){
						System.out.println("���ڂ��I������Ă��܂���");
					}else{
						System.out.println("���[�U�[���폜���܂��� - " + model.getElementAt(index));
						model.remove(index);
					}
				}
			});
		}
		return jButton1;
	}

	/**
	 * This method initializes jRadioButton	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getJRadioButton() {
		if (jRadioButton == null) {
			jRadioButton = new JRadioButton();
			jRadioButton.setBounds(new Rectangle(20, 190, 63, 21));
			jRadioButton.setFont(new Font("Dialog", Font.PLAIN, 12));
			jRadioButton.setText("�I��");
			group.add(jRadioButton);
		}
		return jRadioButton;
	}

	/**
	 * This method initializes jRadioButton1	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getJRadioButton1() {
		if (jRadioButton1 == null) {
			jRadioButton1 = new JRadioButton();
			jRadioButton1.setBounds(new Rectangle(100, 190, 58, 21));
			jRadioButton1.setFont(new Font("Dialog", Font.PLAIN, 12));
			jRadioButton1.setText("�I�t");
			group.add(jRadioButton1);
		}
		return jRadioButton1;
	}

	/**
	 * This method initializes jRadioButton2	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getJRadioButton2() {
		if (jRadioButton2 == null) {
			jRadioButton2 = new JRadioButton();
			jRadioButton2.setBounds(new Rectangle(20, 240, 105, 21));
			jRadioButton2.setFont(new Font("Dialog", Font.PLAIN, 12));
			jRadioButton2.setText("11��22��33�b");
			group1.add(jRadioButton2);
		}
		return jRadioButton2;
	}

	/**
	 * This method initializes jRadioButton3	
	 * 	
	 * @return javax.swing.JRadioButton	
	 */
	private JRadioButton getJRadioButton3() {
		if (jRadioButton3 == null) {
			jRadioButton3 = new JRadioButton();
			jRadioButton3.setBounds(new Rectangle(130, 240, 80, 21));
			jRadioButton3.setFont(new Font("Dialog", Font.PLAIN, 12));
			jRadioButton3.setText("11:22:33");
			group1.add(jRadioButton3);
		}
		return jRadioButton3;
	}

	/**
	 * This method initializes jButton2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton2() {
		if (jButton2 == null) {
			jButton2 = new JButton();
			jButton2.setBounds(new Rectangle(190, 270, 80, 25));
			jButton2.setFont(new Font("Dialog", Font.PLAIN, 12));
			jButton2.setText("����");
			jButton2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("����{�^�����N���b�N");
					save_setting();
					dispose();
				}
			});
		}
		return jButton2;
	}

	protected void save_setting() {
		// TODO �ݒ�ۑ�
		System.out.println("�ݒ�ۑ�");
		if(jRadioButton.isSelected() == true){
			mainwindow.add_a = true;
		}else{
			mainwindow.add_a = false;
		}
		if(jRadioButton2.isSelected() == true){
			mainwindow.show_date_format = true;
		}else{
			mainwindow.show_date_format = false;
		}
		try{
			File file = new File("./setting.txt");
			if (checkBeforeWritefile(file)){
				PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));    
				pw.println(model.getSize());
				for (int i = 0; i < model.getSize(); i++) {
					pw.println((String)model.getElementAt(i));
					System.out.println((String)model.getElementAt(i));
				}
				if(mainwindow.add_a == false){
					pw.println("0");
				}else{
					pw.println("1");
				}
				if(mainwindow.show_date_format == false){
					pw.println("0");
				}else{
					pw.println("1");
				}
				pw.close();
			}else{
				System.out.println("�t�@�C���ɏ������߂܂���");
			}
		}catch(IOException e){
			System.out.println(e);
		}
		CheckOAuth();
	}

	private void CheckOAuth() {
		// TODO �A�J�E���g�F��
		System.out.println("�A�J�E���g�F�؂��J�n���܂�");
		for (int i = 0; i < model.getSize(); i++) {					//�A�J�E���g�񐔕��J��Ԃ�
			//���[�U�[�t�H���_�����݂��邩�m�F
			try{
				File user_directory = new File("./user/");
				if (user_directory.exists()) {
					if (user_directory.isDirectory()) {
					}
				}
				if (!user_directory.mkdir());
			}
			catch(ArrayIndexOutOfBoundsException e) {
				System.out.println(e);
			}
			//�t�H���_�m�F�I��
			//�t�@�C���m�F�J�n
			System.out.println("���[�U�[�t�@�C���m�F - " + model.getElementAt(i));
			File file = new File("./user/" + model.getElementAt(i) + ".txt");
			if(file.exists()){
				System.out.println("���[�U�[�t�@�C���̑��݂��m�F���܂��� - " + model.getElementAt(i));
			}
			else{
				System.out.println("���[�U�[�t�@�C����������܂��� - " + model.getElementAt(i));
				System.out.println("�F�؂��J�n���܂� - " + model.getElementAt(i));
				//�t�@�C���̍쐬�J�n
				//�t�@�C���̍쐬�I��
				// TODO ---------------------------------------------OAuth�F�؊J�n---------------------------------------------
				Twitter twitter = new TwitterFactory().getInstance();

				twitter.setOAuthConsumer("cSq91PiOmq2BTI5WdoKGdQ","TfggWiV8jhmSAhuOFtGP2cOn3PhuALz9ultwViNGo");

				//RequestToken�̎擾
				RequestToken requestToken = null;

				try {
					requestToken = twitter.getOAuthRequestToken();
				} catch (TwitterException e) {
					System.out.println("��O���������܂���" + e);
				}

				AccessToken accessToken = null;

				while(null == accessToken){

					//�u���E�U��OAuth���y�[�W���J��
					String strURL =requestToken.getAuthorizationURL();

					//�u���E�U���N�����A�K�v�� URL ��n��
					String osName = System.getProperty("os.name");

					try {
						if(osName.startsWith("Mac OS")){
							Class<?> fileMgr = null;
							fileMgr = Class.forName("com.apple.eio.FileManager");

							Method openURL = fileMgr.getDeclaredMethod("openURL",new Class[] {String.class});
							openURL.invoke(null, new Object[] {strURL.trim()});

						}else if(osName.startsWith("Windows")){
							Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + strURL.trim());
						}else{
							String[] browsers = {"firefox", "opera", "konqueror","epiphany", "mozilla", "netscape" };

							String browser = null;

							for (int count = 0; count < browsers.length && browser == null; count++)

								if (Runtime.getRuntime().exec(new String[] {"which", browsers[count]}).waitFor() == 0)
									browser = browsers[count];
							
							if (browser == null) {    
							}else {
								Runtime.getRuntime().exec(new String[] {browser, strURL.trim()});
							}
						}
					} catch (IOException e) {
						System.out.println(e);
					} catch (SecurityException e) {
						System.out.println(e);
					} catch (NoSuchMethodException e) {
						System.out.println(e);
					} catch (IllegalArgumentException e) {
						System.out.println(e);
					} catch (IllegalAccessException e) {
						System.out.println(e);
					} catch (InvocationTargetException e) {
						System.out.println(e);
					} catch (ClassNotFoundException e) {
						System.out.println(e);
					} catch (InterruptedException e) {
						System.out.println(e);
					}

					//PIN���͗pJDialog��\������
					String pin = JOptionPane.showInputDialog(null,"�u���E�U�ɕ\������Ă���V����PIN�R�[�h����͂��Ă�������","�F�� - @" + model.getElementAt(i) ,JOptionPane.INFORMATION_MESSAGE);

					try {
						if(pin != null && pin.length() > 0){
							accessToken  = twitter.getOAuthAccessToken(requestToken, pin);
							String token = accessToken.getToken();
						    String tokenSecret = accessToken.getTokenSecret();
							System.out.println(token);
							System.out.println(tokenSecret);
							try{
								file.createNewFile();		  				//���[�U�[�t�@�C���̍쐬
							}catch(IOException e){
								System.out.println(e + "��O���������܂���");
							}
							
							try{
								if (checkBeforeWritefile(file)){
								PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));    
								pw.println(token);
								pw.println(tokenSecret);
								pw.close();
								mainwindow.comboboxmodel.addElement((String)model.getElementAt(i));
								}else{
							        System.out.println("�t�@�C���ɏ������߂܂���");
								}
							}catch(IOException e){
						    	System.out.println(e);
						    }

						}else{
							mainwindow.comboboxmodel.addElement((String)model.getElementAt(i));
							break;
							}
					} catch (TwitterException te) {
						if(401 == te.getStatusCode()){
							System.out.println("�A�N�Z�X�g�[�N�����擾�ł��܂���ł���.");
						}else{
							System.out.println(te);
						}
					}
				}
				// TODO ---------------------------------------------OAuth�F�؏I��---------------------------------------------
			//�t�@�C���m�F�I��
			}
		}
	}

	private boolean checkBeforeWritefile(File file) {
		//�t�@�C���������ݎ��̏������݉\���`�F�b�N����
		if (file.exists()){
			if (file.isFile() && file.canWrite()){
				return true;
			}
			}
		return false;
	}

	/**
	 * This method initializes jScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setBounds(new Rectangle(10, 10, 270, 107));
			jScrollPane.setViewportView(getJList());
		}
		return jScrollPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
